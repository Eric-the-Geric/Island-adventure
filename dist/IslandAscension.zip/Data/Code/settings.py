# Settings for my game

tile_size = 64
player_size = 32
screen_width = 640
screen_height = 640
screen = (screen_width, screen_height)

colour_key = (145, 211, 255)

FPS = 60