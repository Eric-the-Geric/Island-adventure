<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="main_menu" tilewidth="640" tileheight="128" tilecount="5" columns="1">
 <image source="../Graphics/main_menu.png" trans="91d3ff" width="640" height="640"/>
</tileset>
