<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="cloud (192 x 64)" tilewidth="64" tileheight="64" tilecount="3" columns="3">
 <image source="../Graphics/cloud (192 x 64).png" trans="91d3ff" width="192" height="64"/>
</tileset>
