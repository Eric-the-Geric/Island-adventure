<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="water (448 x 322)" tilewidth="64" tileheight="64" tilecount="35" columns="7">
 <image source="../Graphics/water (448 x 322).png" trans="91d3ff" width="448" height="322"/>
</tileset>
