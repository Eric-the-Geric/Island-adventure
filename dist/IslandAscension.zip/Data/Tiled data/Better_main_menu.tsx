<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="Better_main_menu" tilewidth="640" tileheight="107" tilecount="5" columns="1">
 <image source="../Graphics/Better_main_menu.png" trans="91d3ff" width="640" height="640"/>
</tileset>
