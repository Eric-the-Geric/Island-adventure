<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="palm tree (256x322)" tilewidth="64" tileheight="64" tilecount="20" columns="4">
 <image source="../Graphics/palm tree (256x322).png" trans="91d3ff" width="256" height="322"/>
</tileset>
