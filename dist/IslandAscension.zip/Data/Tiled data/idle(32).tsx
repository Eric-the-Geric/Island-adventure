<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="idle(32)" tilewidth="32" tileheight="32" tilecount="4" columns="4">
 <image source="../Graphics/idle(32).png" trans="91d3ff" width="128" height="32"/>
</tileset>
