<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="cococut (14x14)" tilewidth="14" tileheight="14" tilecount="1" columns="1">
 <image source="../Art/cococut (14x14).png" trans="ff7f27" width="14" height="14"/>
</tileset>
